# The implementation of NMF in topic modeling

Implemented non-negative matrix factorization with multiplicative update rules to discover useful topics
